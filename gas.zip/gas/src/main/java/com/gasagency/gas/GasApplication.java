package com.gasagency.gas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasApplication.class, args);
	}

}
